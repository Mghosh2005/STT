# TTS Latency Suite v2 (auto-report per test)

Usage:
1. Fill config.py with your API keys and set TEST_TEXT.
2. Install dependencies: pip install -r requirements.txt
3. Run any script, e.g. python tts_elevenlabs_rest.py
Each script will run one test, append results to tts_results.csv, and auto-generate latency reports (CSV + PDFs).

Notes:
- Streaming scripts are templates: replace websocket URLs and frames per vendor docs.
- Local models require you to install and configure local TTS libraries.
