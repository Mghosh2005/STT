# client/mcp_client.py
import requests

BASE_URL = "http://localhost:8000"

def send_message(to, body):
    payload = {"to": to, "body": body}
    response = requests.post(f"{BASE_URL}/tools/send_message", json=payload)
    return response.json()

if __name__ == "__main__":
    print(send_message("whatsapp:+919876543210", "Hello from MCP client!"))
