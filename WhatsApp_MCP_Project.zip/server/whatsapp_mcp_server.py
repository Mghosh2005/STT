# server/whatsapp_mcp_server.py
from fastapi import FastAPI, Request
from twilio.rest import Client as TwilioClient
import os

app = FastAPI(title="WhatsApp MCP Server")

TW_SID = os.getenv("TW_SID")
TW_AUTH = os.getenv("TW_AUTH")
FROM_WHATSAPP = os.getenv("TW_FROM_WHATSAPP")

tw = TwilioClient(TW_SID, TW_AUTH)

@app.post("/tools/send_message")
async def send_message(req: Request):
    data = await req.json()
    msg = tw.messages.create(
        from_=FROM_WHATSAPP,
        to=data["to"],
        body=data["body"]
    )
    return {"message_id": msg.sid, "status": msg.status}
