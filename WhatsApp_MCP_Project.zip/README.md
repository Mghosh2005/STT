# WhatsApp MCP Server + Client Integration

This project demonstrates integrating **Model Context Protocol (MCP)** with **WhatsApp Business API**
for AI agents and LangChain-based frameworks.

## Features
- Send/receive WhatsApp messages via MCP tools
- Example handler for Twilio WhatsApp Business API
- Client wrapper for custom frameworks (e.g., Django + Celery)
- Fully auditable and modular integration

## Structure
```
server/        # FastAPI MCP server exposing WhatsApp tools
client/        # Python client wrapper for invoking tools
docs/          # Documentation and report files
```
